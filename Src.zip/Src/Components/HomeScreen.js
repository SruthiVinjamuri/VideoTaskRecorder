import React , {useRef, useState, useEffect, useCallback} from 'react';
import {View, Text, StyleSheet, TouchableHighlight, Animated, TouchableNativeFeedback, ToastAndroid} from 'react-native';
import {Camera, useCameraDevices, useFrameProcessor, VideoFile} from 'react-native-vision-camera';
import { DocumentDirectoryPath, moveFile } from 'react-native-fs';
import { scanFaces, Face } from 'vision-camera-face-detector';
// import { runOnJS } from 'react-native-reanimated';


function HomeScreen({navigation, route}) {
 
const hasPermission = route.params;
console.log("has", hasPermission)
  const isRecording = useRef(false);
const[recordVideo, setRecordVideo] = useState(false)
const[recording, setRecording] = useState(false);
const [faces, setFaces] = useState(Face['']);


  const devices = useCameraDevices()
  const device = devices.front
  const camera = useRef(null)
    const takePhotoOptions = {
    qualityPrioritization: 'speed',
    flash: 'off',
    
  };

  useEffect(() => {
    console.log(faces);
  }, [faces]);

  const takePhoto1 = async () => {
    try {
      //Error Handle better
      if (camera.current == null) throw new Error('Camera Ref is Null');
      console.log('Photo taking ....');
      const photo = await camera.current.takePhoto(takePhotoOptions);
      console.log(photo.path)
    } catch (error) {
      console.log(error);
    }
  };

  const stopRecording = useCallback(async () => {
    try {
      if (camera.current == null)
       throw new Error('Camera ref is null!');

      console.log('calling stopRecording()...');
      await camera.current.stopRecording();
      console.log('called stopRecording()!');
    } catch (e) {
      console.error('failed to stop recording!', e);
    }
  }, [camera]);
  const onStoppedRecording = useCallback(() => {
    isRecording.current = false;
    // cancelAnimation(recordingProgress);
   
    console.log('stopped recording video!');
  });

  const startRecording = async() => {
    try{
      ToastAndroid.show("Recording started", ToastAndroid.SHORT)
      var RNFS = require('react-native-fs');
          const path = `${DocumentDirectoryPath}/${Date.now()}.txt`;

      setRecording(true);
    if (camera.current == null) 
    throw new Error('Camera ref is null!');

    console.log('calling startRecording()...');
     const recordVideo = await camera.current.startRecording({
      flash: 'off',
      // fileType: VideoFile,
      onRecordingError: (error) => {
        console.error('Recording failed!', error);
        onStoppedRecording();
      },
      onRecordingFinished: (video) => {
        console.log(`Recording successfully finished! ${video.path}`);
          var filePath = video.path;
          var destPath = RNFS.ExternalDirectoryPath + '/' + 'Sruthi.mp4';
          console.log(filePath, destPath)
          moveFile(filePath, destPath, )
      ToastAndroid.show('File saved in local storage of app',ToastAndroid.SHORT);
        onStoppedRecording();
      },
    });
   
    console.log('called startRecording()!');
    isRecording.current = true;
    setRecordVideo(recordVideo)
  } catch (e) {
    console.error('failed to start recording!', e, 'camera');
  }
  }

  const onLongPressButton = () => {
    setRecording(true);
    startRecording();
  }

  const frameProcessor = useFrameProcessor((frame) => {
    'worklet';
    const scannedFaces = scanFaces(frame);
    // runOnJS(setFaces)(scannedFaces);
  }, []);

  const boxOverlayStyle = useAnimatedStyle(() => ({
    position: 'absolute',
    borderWidth: 1,
    borderColor: 'red',
    ...scannedFaces.value
  }), [scannedFaces])



  function renderCamera() {
    if (device == null) {
      return (
        <View>
          <Text style={{ color: '#fff' }}>Loading</Text>
        </View>
      )
    }
    else {
      return (
        <View style={styles.preview}>
          {device != null &&
            hasPermission  && (
              <View>
                <Camera
                  ref={camera}
                  style={StyleSheet.absoluteFill}
                  device={device}
                  isActive={true}
                  photo={false}
                  video={true}
                  audio = {true}
                  frameProcessor = {frameProcessor}
                  
                />
                 <Reanimated.View style={boxOverlayStyle} />
                <TouchableHighlight
                style ={styles.cameraButton}
               
              onPress={async () => {
            console.log("btn clicked");
            if (!recording) {

              startRecording();
              setRecording(true);
            } else {
              setRecording(false);
              stopRecording();
            }
          }}>
               
               <View style ={styles.cameraButtonInner}/>
                </TouchableHighlight>
                
              </View>
            )}
        </View>
      )
    }


  }
  return (
    <View style={{ flex: 1 }}>
      {renderCamera()}
    </View>
  );
}


export default HomeScreen;

const styles = StyleSheet.create({
 
  camera: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  cameraButton: {
    width: 78,
    height: 78,
    borderRadius: 78 / 2,
    borderWidth: 5,
    borderColor: 'red',
  },
  cameraButtonInner: {
    width: 68,
    height: 68,
    borderRadius: 68 / 2,
    borderWidth: 5,
    borderColor: 'red',
    // backgroundColor: {recording ? 'red' : "white"},
  },
  preview: {
  flex: 1,
  justifyContent: 'flex-end',
  alignItems: 'center',
  width: '100%',
  height: '100%'
}
})

