
import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableHighlight,
  useColorScheme,
  View,
  AsyncStorage,
  Alert,
  ToastAndroid
 
} from 'react-native';
import { NativeScreenNavigationContainer } from 'react-native-screens';

const RegisterScreen = ({navigation}) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

const  registerUser = () => {

    // if(!name) {
    //   alert('Name is required');
    //   return;
    // }
    // if(!email) {
    //   alert('Email is required');
    //   return;
    // }
    ToastAndroid.show(`${name} registered successfully`, ToastAndroid.SHORT);
    // navigation.navigate("Permission")
    console.log('user successfully signed up!: ', name);
    // setName(" ");
    // setEmail(" ");
   
}
  return(
    <View style = {styles.container}>
     
      <TextInput 
        style = {styles.input}
        value = {name}
        onChangeText = {(text) => setName(text)}
        autoCapitalize="none"
        placeholder="Enter Name"
        placeholderTextColor="#8b9cb5"
        
      />

<TextInput 
        style = {styles.input}
        value = {email}
        onChangeText = {(text) => setEmail(text)}
        autoCapitalize="none"
        placeholder="Enter Email"
        placeholderTextColor="#8b9cb5"
        keyboardType="email-address"
      />

      <TouchableHighlight 
      onPress={registerUser}
      activeOpacity={0.6}
      underlayColor="white">
      <View style = {styles.button}>
      <Text>Register</Text>
      </View>

      </TouchableHighlight>
      <TouchableHighlight 
      
      activeOpacity={0.6}
      underlayColor="white"
      onPress = {() =>navigation.navigate('Permission')}>
      <View style = {styles.button}>

        <Text>Take Permission</Text>
        </View>
      </TouchableHighlight>



    </View>
  )
}
export default RegisterScreen;


const styles = StyleSheet.create({
  input : {
    height: 40,
    width: 300,
    // alignItems: 'center',
    marginBottom: 10,
    color: '#307ecc',
    
    borderRadius: 30,
    backgroundColor: 'skyblue',
    margin: 10,
    padding: 8,
    borderRadius: 14,
    fontSize: 18,
   
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center'
  },
button : {
  height: 40,
  width: 150,
  // alignItems: 'center',
  marginBottom: 10,
  color: '#307ecc',
  
  borderRadius: 30,
  backgroundColor: 'skyblue',
  margin: 10,
  padding: 8,
  borderRadius: 14,
  fontSize: 18,
  alignItems: 'center'
}


});

