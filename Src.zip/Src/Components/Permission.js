import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { StyleSheet, View, Text, ViewProps, ToastAndroid } from 'react-native';
import { TouchableHighlight } from 'react-native-gesture-handler';
import { Camera, CameraPermissionStatus } from 'react-native-vision-camera';
import { Alert } from 'react-native/Libraries/Alert/Alert';


const Permission = ({navigation}) => {
    const [hasPermission, setHasPermission] = useState(false);
    const [hasMicroPermission, setHasMicroPermission] = useState(false);

    const requestMicrophonePermission = useCallback(async () => {
        console.log('Requesting microphone permission...');
        const permission = await Camera.requestMicrophonePermission();
        console.log(`Microphone permission status: ${permission}`);
    
        // if (permission === 'denied') await Linking.openSettings();
        setHasMicroPermission(permission);
      }, []);

const requestCameraPermission = useCallback(async () => {
    console.log('Requesting camera permission...');
    const permission = await Camera.requestCameraPermission();
    console.log(`Camera permission status: ${permission}`);

    // if (permission === 'denied') await Linking.openSettings();
    setHasPermission(permission);
  }, []);

  useEffect(() => {
    if (hasPermission === 'authorized' && hasMicroPermission === 'authorized') 
    // navigation.navigate('Home');
    ToastAndroid.show(`Permissions granted`, ToastAndroid.SHORT);

  }, [hasPermission, hasMicroPermission, navigation]);

  return(
    <View style={styles.container}>
  
    <View style={styles.permissionsContainer}>
        <Text style={styles.permissionText}>
          Vision Camera needs <Text style={styles.bold}>Camera permission</Text>.{' '}
          <Text style={styles.hyperlink} onPress={requestCameraPermission}>
            Grant
          </Text>
        </Text>
    
      
        <Text style={styles.permissionText}>
          Vision Camera needs <Text style={styles.bold}>Microphone permission</Text>.{' '}
          <Text style={styles.hyperlink} onPress={requestMicrophonePermission}>
            Grant
          </Text>
        </Text>
      
      <TouchableHighlight onPress={() => navigation.replace('Home', 'authorized')}>
      <View style = {styles.button}>
      <Text>Launch Camera</Text>
      </View>
       
      </TouchableHighlight>
    </View>
  </View>
  )
}

const styles = StyleSheet.create({
    welcome: {
      fontSize: 38,
      fontWeight: 'bold',
      maxWidth: '80%',
    },
   
    container: {
      flex: 1,
      backgroundColor: 'white',
   
    },
    permissionsContainer: {
      marginTop:  12,
    },
    permissionText: {
      fontSize: 17,
    },
    hyperlink: {
      color: '#007aff',
      fontWeight: 'bold',
    },
    bold: {
      fontWeight: 'bold',
    },
    button : {
      height: 40,
      width: 150,
      // alignItems: 'center',
      marginBottom: 10,
      color: '#307ecc',
      
      borderRadius: 30,
      backgroundColor: 'skyblue',
      margin: 10,
      padding: 8,
      borderRadius: 14,
      fontSize: 18,
      alignItems: 'center'
    }
  });

export default Permission;